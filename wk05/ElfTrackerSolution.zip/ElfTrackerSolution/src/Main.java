import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Scanner;

public class Main {

    //A better way to perhaps organize this would be to create an ElfTracker class
    // that manages its elves list and stores what are static methods here as normal
    // methods for the specific list.

    public static void main(String[] args) {
        //initialize the elf list
        ArrayList<Elf> elves = loadElvesFromFile("elves.txt"); //we'll load from file using a static method

        //configure values for our main loop
        boolean done = false;
        Scanner scan = new Scanner(System.in);

        //start the main menu loop
        while (!done) {
            System.out.println("Welcome to Elf Tracker.");
            System.out.println("Enter 1 to view elf list, 2 to add an elf, 0 to exit:");
            String choice = scan.nextLine();
            if (choice.equals("1")) {
                viewElves(elves); //we could have put the code here, but it cleans things to split it up into a static method
            } else if (choice.equals("2")) {
                addElf(elves); //same as above, we'll update the arrayList using a static method
            } else if (choice.equals("0")) {
                done = true;
            } else {
                System.out.println("Invalid choice.");
            }
        }
        System.out.println("Thank you for using the elf tracker.");
        scan.close();
    }

    //we use this method to return our initial elf list from file, found in elves.txt in the root of the project
    private static ArrayList<Elf> loadElvesFromFile(String fileName) {
        ArrayList<Elf> elves = new ArrayList<>();
        try {
            File file = new File(fileName);
            Scanner fileScan = new Scanner(file);  //we can use a Scanner to read files as well as input!
            while (fileScan.hasNextLine()) {
                String name = fileScan.nextLine(); //we assume the name is the first line
                int height = Integer.parseInt(fileScan.nextLine()); //we assume the height is the second line
                elves.add(new Elf(name, height));
            }
            fileScan.close();
        } catch (FileNotFoundException e) {
            System.out.println("Error: File not found: " + fileName);
            System.out.println("Starting with empty Elf list.");
        }
        return elves; //return the list to work with
    }

    //just handles the logic for looping through the elves and printing them
    private static void viewElves(ArrayList<Elf> elves) {
        if (elves.isEmpty()) {
            System.out.println("No elves found.");
        } else {
            for (int i = 0; i < elves.size(); i++) {
                System.out.println(elves.get(i)); //we're not specifying a method on the elf, but since we're passing it where
                                                  // a string is expected, it'll implicitly call toString()
            }
        }
    }

    //this modified the list
    private static void addElf(ArrayList<Elf> elves) { //since we're passing an object, we can modify the object in place
        Scanner scan = new Scanner(System.in);
        System.out.println("Please enter elf name:");
        String name = scan.nextLine();
        System.out.println("Please enter elf height in inches (ints only):");
        int height = Integer.parseInt(scan.nextLine());
        elves.add(new Elf(name, height));
    }
}
