/*
*** Jeffrey Walley | CTEC151 Advanced Java | Portfolio Project: Comic Keeper - very basic comic list | 09/23/2024
 */

package portfolio_comickeeper;

import java.util.Scanner;
import java.io.*;

public class Main {
    public static void main(String[] args) throws IOException {
        Scanner scanner = new Scanner(System.in);
        boolean keepRunning = true;

        System.out.println("*".repeat(80));
        System.out.println("Welcome to Jeffrey Walley's Comic Keeper");
        System.out.println("a very basic comic book list made for my Java 151 Portfolio Project");
        System.out.println("*".repeat(80));

        while (keepRunning) {
            System.out.println("\nComic Keeper Menu");
            System.out.println("1. Add a comic book");
            System.out.println("2. List comic book collection");
            System.out.println("0. Quit");
            System.out.print("Enter your choice: ");

            int choice = scanner.nextInt();

            switch (choice) {
                case 1:
                    AddComicBook addComicBook = new AddComicBook();
                    addComicBook.addComicBook();
                    break;
                case 2:
                    ListComicBooks listComicBooks = new ListComicBooks();
                    break;
                case 0:
                    keepRunning = false;
                    break;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }
        scanner.nextLine();
            System.out.println("Thank you for using Comic Keeper!");
    }
}



