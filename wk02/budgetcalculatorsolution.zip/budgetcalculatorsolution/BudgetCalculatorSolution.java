package budgetcalculatorsolution;

import java.util.Scanner;

/**
 *
 * @author Steven Turner
 */
public class BudgetCalculatorSolution {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        //set up Scanner object
        Scanner scan = new Scanner(System.in);
        // retrieve budget values
        System.out.println("What is your housing budget percent(written as 0.XX for the percent)");
        double housing = scan.nextDouble();
        System.out.println("What is your transportation budget percent(written as 0.XX for the percent)");
        double transportation = scan.nextDouble();
        System.out.println("What is your food budget percent?");
        double food = scan.nextDouble();
        System.out.println("Assuming savings is what's left over:");
        double savings = 1 - housing - transportation - food;
        System.out.println("Savings percent is " + savings);
        
        System.out.println("What is your monthly income?");
        double income = scan.nextDouble();
        
        System.out.println("Processing budget...");
        double housingCash = housing * income;
        double transportationCash = transportation * income;
        double foodCash = food * income;
        double savingsCash = savings * income;
        
        System.out.println("Budget items are:");
        System.out.println("Housing cash is about " + (int) housingCash + ", exactly: " + housingCash);
        System.out.println("Transportation cash is about " + (int) transportationCash + ", exactly: " + transportationCash);
        System.out.println("Food cash is about " + (int) foodCash + ", exactly: " + foodCash);
        System.out.println("Savings cash is about " + (int) savingsCash + ", exactly: " + savingsCash);
    }
    
}
